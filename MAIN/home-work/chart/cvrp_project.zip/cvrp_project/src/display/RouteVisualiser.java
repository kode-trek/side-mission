/******************************************************************************
 * 
 * Route Visualiser class. Outputs the arrays provided as a graph.
 * 
 * Shows the path for each truck and total length for each path
 * 
 *****************************************************************************/

package display;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.LinkedList;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

import cvrp.CVRPData;

public class RouteVisualiser extends JPanel{
	
	private BufferedImage b;
	private Graphics2D g;
	private final LinkedList<Oval> ovals = new LinkedList<Oval>();
	private final LinkedList<Char> chars = new LinkedList<Char>();
	private final LinkedList<Line> lines = new LinkedList<Line>();
	
	
	
	public void addOval(int x1, int x2, int x3, int x4, Color color) {
		Oval o=new Oval();
		o.setX1(x1); o.setY1(x2); o.setX2(x3); o.setY2(x4); o.setColor(color);
	    ovals.add(o);        
	    repaint();
	}
	
	public void addLine(int x1, int x2, int x3, int x4, Color color) {
		Line l=new Line();
		l.setX1(x1); l.setY1(x2); l.setX2(x3); l.setY2(x4); l.setColor(color);
	    lines.add(l);        
	    repaint();
	}
	
	public void addChar(char[] s,int x1, int x2, int x3, int x4, Color color) {
		Char c=new Char();
		c.setX1(x1); c.setY1(x2); c.setX2(x3); c.setY2(x4); c.setColor(color); c.setC(s);
	    chars.add(c);        
	    repaint();
		
	}
	
	
	@Override
    public void paintComponent(Graphics g)
    {
        for (Oval ov : ovals) {
            g.setColor(ov.getColor());
            g.drawOval(ov.getX1(), ov.getY1(), ov.getX2(), ov.getY2());
        }
        
        for(Char ch: chars){
        	g.setColor(ch.getColor());
        	g.drawChars(ch.getC(),ch.getX1(), ch.getY1(), ch.getX2(), ch.getY2());
        }
        
        for(Line l: lines){
        	g.setColor(l.getColor());
        	g.drawLine(l.getX1(), l.getY1(), l.getX2(), l.getY2());
        }

    }

	

	public RouteVisualiser(boolean withKey){
		JFrame frame = new JFrame();
        frame.setSize(400, 420);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBackground(Color.black);
        frame.setContentPane(this);

        frame.setVisible(true);
        frame.invalidate();
        
		b = new BufferedImage(withKey ? 920 : 770 ,770,BufferedImage.TYPE_INT_RGB);
		g = b.createGraphics();
	}
	

	public void getNodeMap(){
		
	    Oval ov=new Oval();
		char[] s = String.valueOf(CVRPData.getDemand(1)).toCharArray();
		g.setColor(Color.green);
		g.drawOval(CVRPData.getCoords().get(1).getX()/*[1][CVRPData.X_COORDINATE]*/ * 10, CVRPData.getCoords().get(1).getY()/*[1][CVRPData.Y_COORDINATE]*/ * 10, 2, 2);
		ov.setColor(Color.green);
		addOval(CVRPData.getCoords().get(1).getX() * 10, CVRPData.getCoords().get(1).getY() * 10, 2, 2, Color.green);
		g.setColor(Color.green);
		g.drawChars( s, 0, s.length, CVRPData.getCoords().get(1).getX()/*[1][CVRPData.X_COORDINATE]*/ * 10 + 5, CVRPData.getCoords().get(1).getY()/*[1][CVRPData.Y_COORDINATE]*/ * 10 - 5);
		addChar(s, 0, s.length, CVRPData.getCoords().get(1).getX()* 10 + 5, CVRPData.getCoords().get(1).getY()* 10 - 5, Color.green);
		for(int i = 2; i <= CVRPData.NUM_NODES; i++){
			s = String.valueOf(CVRPData.getDemand(i)).toCharArray();
			g.setColor(Color.red);
			g.drawOval(CVRPData.getCoords().get(i).getX()/*[i][CVRPData.X_COORDINATE]*/ * 10, CVRPData.getCoords().get(i).getY()/*[i][CVRPData.Y_COORDINATE]*/ * 10, 2, 2);
			addOval(CVRPData.getCoords().get(i).getX() * 10, CVRPData.getCoords().get(i).getY() * 10, 2, 2, Color.red);
			g.setColor(Color.white);
			g.drawChars( s, 0, s.length, CVRPData.getCoords().get(i).getX()/*[i][CVRPData.X_COORDINATE]*/ * 10 + 10, CVRPData.getCoords().get(i).getY()/*[i][CVRPData.Y_COORDINATE]*/ * 10 - 10);
			addChar(s, 0, s.length, CVRPData.getCoords().get(i).getX()* 10 + 5, CVRPData.getCoords().get(i).getY()* 10 - 5, Color.white);
		}
	}
	
	public void drawPaths(int[][] paths){
		System.out.println("draw path");
//		System.out.println(paths.length);
		for (int i = 0; i < paths.length && paths[i] != null; i++ ){
//			System.out.println(paths[i]+" "+paths[i].length);
			g.setColor(Color.getHSBColor((float)((0.19 * i + 1.0) % 1.0), 0.8f, 1.0f));
			Color c=Color.getHSBColor((float)((0.19 * i + 1.0) % 1.0), 0.8f, 1.0f);
			for(int j = 0; j < paths[i].length - 1; j++){
//				System.out.println("i="+i+",j="+j+",p= "+paths[i][j+1]);
				g.drawLine(CVRPData.getCoords().get(paths[i][j]).getX()/*[paths[i][j]][CVRPData.X_COORDINATE]*/ * 10, CVRPData.getCoords().get(paths[i][j]).getY()/*[paths[i][j]][CVRPData.Y_COORDINATE]*/ * 10,
						CVRPData.getCoords().get(paths[i][j+1]).getX()/*[paths[i][j+1]][CVRPData.X_COORDINATE]*/ * 10 , CVRPData.getCoords().get(paths[i][j+1]).getY()/*[paths[i][j+1]][CVRPData.Y_COORDINATE]*/ * 10 );
				addLine(CVRPData.getCoords().get(paths[i][j]).getX() * 10, CVRPData.getCoords().get(paths[i][j]).getY() * 10,
						CVRPData.getCoords().get(paths[i][j+1]).getX() * 10 , CVRPData.getCoords().get(paths[i][j+1]).getY() * 10 , c);
			}
		}
	}
	
	public void drawKey(int[][] paths){
		System.out.println("drawkey");
		int numPaths = 0;
		int i = 0;
//		while(paths[i] != null){
//			numPaths++;
//			System.out.println(numPaths);
//		}
		
		int boxtop = ( 770 - (numPaths * 30 + 50)) / 2;
		
		// Draw a box for the key
		g.setColor(Color.white);
		g.drawRect(730, boxtop, 180, numPaths * 30 + 50);
		// Add the title
		String title = new String("Path Total Weights");
		g.drawChars(title.toCharArray(), 0, title.length(), 770, boxtop + 30);
		
		for(i = 0; i < paths.length && paths[i] != null; i++){
			System.out.print(i+" ,path=[");
			for(int j=0; j<paths[i].length;j++)
				System.out.print(paths[i][j]+",");
			System.out.println("]");
			g.setColor(Color.getHSBColor((float)((0.19 * i + 1.0) % 1.0), 0.8f, 1.0f));
			g.drawLine(770, boxtop + 50 + i*30, 820, boxtop + 50 + i*30);
			String weight = String.format("%1$,.2f", 
					CVRPData.getPathDistance(paths[i]));
			g.setColor(Color.white);
			g.drawChars(weight.toCharArray(), 0, weight.length(), 830, boxtop + 55 + i*30);
		}
	}
	
	public void saveImage(String filename){
		try{
			System.out.println(filename + "-route.png");
			ImageIO.write(b,"png",new File(filename + "-route.png"));
			System.out.println("save image");
			}catch (Exception e) {
				System.out.println("can not save image");
			}
	}

}
